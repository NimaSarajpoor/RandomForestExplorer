# Got help from:
# https://betterscientificsoftware.github.io/python-for-hpc/tutorials/python-pypi-packaging/

__version__ = "0.1.0"
__author__ = 'Nima Sarajpoor'
