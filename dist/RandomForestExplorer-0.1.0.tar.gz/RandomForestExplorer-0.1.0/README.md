# RandomForestExplorer
Using eXplainable AI (XAI) to digest decisions made by random forest
